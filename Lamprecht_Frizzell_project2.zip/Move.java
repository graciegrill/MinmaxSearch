public class Move {
    //Used to mitigate the lack of multiple returns in java
    public int value;
    public int move;

    
}
